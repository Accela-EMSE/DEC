lic = new License_OBJ(LIC01_JUNIOR_HUNTING_TAGS, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC02_MARINE_REGISTRY, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC03_ONE_DAY_FISHING_LICENSE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC04_BOWHUNTING_PRIVILEGE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC05_DEER_MANAGEMENT_PERMIT, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC06_HUNTING_LICENSE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC07_MUZZLELOADING_PRIVILEGE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC08_TURKEY_PERMIT, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC09_LIFETIME_BOWHUNTING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC10_LIFETIME_FISHING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC11_LIFETIME_MUZZLELOADING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC12_LIFETIME_SMALL_AND_BIG_GAME, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC13_LIFETIME_SPORTSMAN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC14_LIFETIME_TRAPPING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC15_TRAPPING_LICENSE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC16_HABITAT_ACCESS_STAMP, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC17_VENISON_DONATION, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC18_CONSERVATION_FUND, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC19_TRAIL_SUPPORTER_PATCH, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC20_CONSERVATIONIST_MAGAZINE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC21_CONSERVATION_PATRON, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC22_FRESHWATER_FISHING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC23_NONRES_FRESHWATER_FISHING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC24_NONRESIDENT_1_DAY_FISHING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC25_NONRESIDENT_7_DAY_FISHING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC26_SEVEN_DAY_FISHING_LICENSE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC27_CONSERVATION_LEGACY, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC28_JUNIOR_BOWHUNTING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC29_JUNIOR_HUNTING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC30_NONRES_MUZZLELOADING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC31_NONRES_SUPER_SPORTSMAN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC32_NONRESIDENT_BEAR_TAG, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC33_NONRESIDENT_BIG_GAME, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC34_NONRESIDENT_BOWHUNTING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC35_NONRESIDENT_SMALL_GAME, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC36_NONRESIDENT_TURKEY, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC37_SMALL_AND_BIG_GAME, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC38_SMALL_GAME, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC39_SPORTSMAN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC40_SUPER_SPORTSMAN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC41_NONRESIDENT_TRAPPING, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC42_TRAPPER_SUPER_SPORTSMAN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC43_LIFETIME_CARD_REPLACE, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC44_SPORTSMAN_ED_CERTIFICATION, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC45_LIFETIME_INSCRIPTION, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC46_TAG_REG_SEASON_DEER, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC47_TAG_BEAR, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC48_TAG_BOW_MUZZ_EITHER_SEX, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC49_TAG_BOW_MUZZ_ANTLERLESS, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC50_TAG_SPRING_TURKEY_TAG, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC51_TAG_FALL_TURKEY_TAG, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC52_TAG_BACK, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC53_TAG_DMP_DEER, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC56_TAG_DRIV_LIC_IMM, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC57_TAG_DRIV_LIC_REN, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC58_HUNTING_LICENSE_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC59_HUNTING_LICENSE_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC60_BOWHUNTING_PRIVILEGE_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC61_BOWHUNTING_PRIVILEGE_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC62_MUZZLELOADING_PRIVILEGE_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC63_MUZZLELOADING_PRIVILEGE_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC64_TRAPPING_LICENSE_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC65_TRAPPING_LICENSE_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC66_FRESHWATER_FISHING_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC67_FRESHWATER_FISHING_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC68_TURKEY_PERMIT_3Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;
lic = new License_OBJ(LIC69_TURKEY_PERMIT_5Y, true)
            this.licObjARRAY[this.licObjARRAY.length] = lic;
            this.licensesNameArray[lic.Identity] = this.licObjARRAY.length - 1;

			
			
			function MyStartingPoint(itemCap) {
    logDebug("Elapsed Time: " + elapsed());

	
var f = new form_OBJECT(GS2_EXPR, OPTZ_TYPE_ALLFEES);

f.Year = "2013";
f.DOB = "12/12/1978";
f.Email = "lalit@gcomsoft.com";
f.IsNyResiDent = "Yes";
f.IsMilitaryServiceman = "No";
f.IsLegallyBlind = "No";
f.IsNativeAmerican = ("No");
f.PreferencePoints = "2";
f.SetAnnualDisability("");
f.SetPriorLicense("");
f.SetSportsmanEducation("");
f.SetLandOwnerInfo("");
f.Quantity_Trail_Supporter_Patch = "1";
f.Quantity_Venison_Donation = "1";
f.Quantity_Conservation_Patron = "1";
f.Quantity_Conservation_Fund = "1";
f.Quantity_Conservationist_Magazine = "1";
f.Quantity_Habitat_Stamp = "1";
f.IsPermanentDisabled = "1";
f.SetActiveHoldingsInfo("");
f.DriverLicenseState = "NY";
f.DriverLicenseNumber = "123456789";
f.NonDriverLicenseNumber = "";
f.SetEnforcementAttrib("No", "No", "No", "No");
f.SetFulfillmentAttrib("", "");
f.FromACA = "No";
f.UserIdEB = "LGAWAD";
f.RecordType = "";
//

//Set control array and set values for lic
for (var idx = 0; idx < f.licObjARRAY.length; idx++) {
    f.SetSelected(f.licObjARRAY[idx].Identity, false);
}
////


//Call rules
f.ExecuteBoRuleEngine();
////

////Set Lic availablity using lic array from app object
for (var idx = 0; idx < f.licObjARRAY.length; idx++) {
    //var oTemp = new License_OBJ();
    var oLic = f.licObjARRAY[idx];

    if (f.licObjARRAY[idx].ExprFieldName != "") {
        if (f.licObjARRAY[idx].Message != "") {
            logDebug(f.licObjARRAY[idx].Message);
        }
    }
}
////
	
	
    logDebug("Elapsed Time: " + elapsed());

	}


	
	
	
function SetVesrionSalesItems2012() {
    var emptyArray = new Array();
    // identity, recordType, feeSched, feeVersion, fnFeeRule, fnIsSelectableRule, fnprereqisiteArray, fnIncludesArray, fntagsArray, verifyRevokedHunting, verifyRevokedTrapping, verifyRevokedFishing) 
    emptyArray.push(new SalesItemProp(LIC08_TURKEY_PERMIT, AA08_TURKEY_PERMIT, FEE_ANNUAL_TURKEY_PERMIT_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_TRKY_2012", "isRuleForSelectable_ANNUAL_TRKY_2012", "getPrereq_ANNUAL_TRKY_2012", null, "getTag_ANNUAL_TRKY_2012", true, false, false));
    emptyArray.push(new SalesItemProp(LIC07_MUZZLELOADING_PRIVILEGE, AA07_MUZZLELOADING_PRIVILEGE, FEE_ANNUAL_MUZZLELOADING_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_MUZZ_2012", "isRuleForSelectable_ANNUAL_MUZZ_2012", "getPrereq_ANNUAL_MUZZ_2012", null, "getTag_ANNUAL_MUZZ_2012", true, false, false));
    emptyArray.push(new SalesItemProp(LIC05_DEER_MANAGEMENT_PERMIT, AA05_DEER_MANAGEMENT_PERMIT, FEE_ANNUAL_DMP_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_DMP", "isRuleForSelectable_ANNUAL_DMP_2012", "getPrereq_ANNUAL_DMP_2012", null, "getTag_ANNUAL_DMP_2012", true, false, false));
    emptyArray.push(new SalesItemProp(LIC04_BOWHUNTING_PRIVILEGE, AA04_BOWHUNTING_PRIVILEGE, FEE_ANNUAL_BOWHUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_BOWH_2012", "isRuleForSelectable_ANNUAL_BOWH_2012", "getPrereq_ANNUAL_BOWH_2012", null, "getTag_ANNUAL_BOWH_2012", true, false, false));
    emptyArray.push(new SalesItemProp(LIC27_CONSERVATION_LEGACY, AA27_CONSERVATION_LEGACY, FEE_ANL_CONSERV_LEGACY_SCHDL, "1", "getAllFeeCodeByRuleFor_CONSERVATION_LEGACY", "isRuleForSelectable_CONSERVATION_LEGACY", null, "getIncl_CONSERVATION_LEGACY", "getTag_CONSERVATION_LEGACY", true, false, true));
    emptyArray.push(new SalesItemProp(LIC28_JUNIOR_BOWHUNTING, AA28_JUNIOR_BOWHUNTING, FEE_ANL_JUNIOR_BOWHUNT_SCHDL, "1", "getAllFeeCodeByRuleFor_JUNIOR_BOWHUNTING", "isRuleForSelectable_JUNIOR_BOWHUNTING", null, "getIncl_JUNIOR_BOWHUNTING", "getTag_JUNIOR_BOWHUNTING", true, false, false));
    emptyArray.push(new SalesItemProp(LIC29_JUNIOR_HUNTING, AA29_JUNIOR_HUNTING, FEE_ANL_JUNIOR_HUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_JUNIOR_HUNTING", "isRuleForSelectable_JUNIOR_HUNTING", null, "getIncl_JUNIOR_HUNTING", "getTag_JUNIOR_HUNTING", true, false, false));
    emptyArray.push(new SalesItemProp(LIC01_JUNIOR_HUNTING_TAGS, AA57_JUNIOR_HUNTING_TAGS, FEE_ANL_JUNIOR_HUNT_TAG_SCHDL, "1", "getAllFeeCodeByRuleFor_JUNIOR_HUNT_TAGS", "isRuleForSelectable_JUNIOR_HUNT_TAGS", null, null, "getTag_JUNIOR_HUNT_TAGS", true, false, false));
    emptyArray.push(new SalesItemProp(LIC33_NONRESIDENT_BIG_GAME, AA33_NONRESIDENT_BIG_GAME, FEE_ANL_NONRES_BIGGAME_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_BIG_GAME", "isRuleForSelectable_NONRESIDENT_BIG_GAME", null, null, "getTag_NONRESIDENT_BIG_GAME", true, false, true));
    emptyArray.push(new SalesItemProp(LIC34_NONRESIDENT_BOWHUNTING, AA34_NONRESIDENT_BOWHUNTING, FEE_ANL_NONRES_BOWHUNT_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_BOWHUNTING", "isRuleForSelectable_NONRESIDENT_BOWHUNTING", null, "getIncl_NONRESIDENT_BOWHUNTING", "getTag_NONRESIDENT_BOWHUNTING", true, false, false));
    emptyArray.push(new SalesItemProp(LIC35_NONRESIDENT_SMALL_GAME, AA35_NONRESIDENT_SMALL_GAME, FEE_ANL_NONRES_SMALLGAME_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_SMALL_GAME", "isRuleForSelectable_NONRESIDENT_SMALL_GAME", null, "getIncl_NONRESIDENT_SMALL_GAME", "getTag_NONRESIDENT_SMALL_GAME", true, false, false));
    //Added fnprerequisiteArray to NONRES_MUZZLELOADING
    emptyArray.push(new SalesItemProp(LIC30_NONRES_MUZZLELOADING, AA30_NONRES_MUZZLELOADING, FEE_ANL_NONRESMUZZLELOAD_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRES_MUZZLELOADING", "isRuleForSelectable_NONRES_MUZZLELOADING", "getPrereq_NONRES_MUZZLELOADING", "getIncl_NONRES_MUZZLELOADING", "getTag_NONRES_MUZZLELOADING", true, false, false));
    emptyArray.push(new SalesItemProp(LIC31_NONRES_SUPER_SPORTSMAN, AA31_NONRES_SUPER_SPORTSMAN, FEE_ANL_NONRES_SUPSPORTS_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRES_SUPER_SPORTSMAN", "isRuleForSelectable_NONRES_SUPER_SPORTSMAN", null, "getIncl_NONRES_SUPER_SPORTSMAN", "getTag_NONRES_SUPER_SPORTSMAN", true, false, true));
    emptyArray.push(new SalesItemProp(LIC37_SMALL_AND_BIG_GAME, AA37_SMALL_AND_BIG_GAME, FEE_ANL_SMALL_BIG_GAME_SCHDL, "1", "getAllFeeCodeByRuleFor_SMALL_AND_BIG_GAME", "isRuleForSelectable_SMALL_AND_BIG_GAME", null, "getIncl_SMALL_AND_BIG_GAME", "getTag_SMALL_AND_BIG_GAME", true, false, true));
    emptyArray.push(new SalesItemProp(LIC39_SPORTSMAN, AA39_SPORTSMAN, FEE_ANNUAL_SPORTSMAN_SCHDL, "1", "getAllFeeCodeByRuleFor_SPORTSMAN", "isRuleForSelectable_SPORTSMAN", null, "getIncl_SPORTSMAN", "getTag_SPORTSMAN", true, false, true));
    emptyArray.push(new SalesItemProp(LIC38_SMALL_GAME, AA38_SMALL_GAME, FEE_ANNUAL_SMALL_GAME_SCHDL, "1", "getAllFeeCodeByRuleFor_SMALL_GAME", "isRuleForSelectable_SMALL_GAME", null, "getIncl_SMALL_GAME", "getTag_SMALL_GAME", true, false, true));
    emptyArray.push(new SalesItemProp(LIC40_SUPER_SPORTSMAN, AA40_SUPER_SPORTSMAN, FEE_ANL_SUPER_SPORTSMAN_SCHDL, "1", "getAllFeeCodeByRuleFor_SUPER_SPORTSMAN", "isRuleForSelectable_SUPER_SPORTSMAN", null, "getIncl_SUPER_SPORTSMAN", "getTag_SUPER_SPORTSMAN", true, false, true));
    emptyArray.push(new SalesItemProp(LIC41_NONRESIDENT_TRAPPING, AA41_NONRESIDENT_TRAPPING, FEE_ANL_NONRESI_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_TRAPPING", "isRuleForSelectable_NONRESIDENT_TRAPPING", null, "getIncl_NONRESIDENT_TRAPPING", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC42_TRAPPER_SUPER_SPORTSMAN, AA42_TRAPPER_SUPER_SPORTSMAN, FEE_ANL_TRAP_SUPSPORTS_SCHDL, "1", "getAllFeeCodeByRuleFor_TRAPPER_SUPER_SPORTSMAN", "isRuleForSelectable_TRAPPER_SUPER_SPORTSMAN", null, "getIncl_TRAPPER_SUPER_SPORTSMAN", "getTag_TRAPPER_SUPER_SPORTSMAN", true, true, true));
    emptyArray.push(new SalesItemProp(LIC15_TRAPPING_LICENSE, AA15_TRAPPING_LICENSE, FEE_ANNUAL_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_TRAP_2012", "isRuleForSelectable_ANNUAL_TRAP_2012", null, null, null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC36_NONRESIDENT_TURKEY, AA36_NONRESIDENT_TURKEY, FEE_ANL_NONRES_TURKEY_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_TURKEY", "isRuleForSelectable_NONRESIDENT_TURKEY", "getPrereq_NONRESIDENT_TURKEY", "getIncl_NONRESIDENT_TURKEY", "getTag_NONRESIDENT_TURKEY", true, false, false));

    emptyArray.push(new SalesItemProp(LIC22_FRESHWATER_FISHING, AA22_FRESHWATER_FISHING, FEE_ANL_FRESHWATER_FISH_SCHDL, "1", "getAllFeeCodeByRuleFor_FRESHWATER_FISHING_2012", "isRuleForSelectable_FRESHWATER_FISHING_2012", null, "getIncl_FRESHWATER_FISHING_2012", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC24_NONRESIDENT_1_DAY_FISHING, AA24_NONRESIDENT_1_DAY_FISHING, FEE_ANL_NONRES_1DAY_FISH_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_1_DAY_FISHING", "isRuleForSelectable_NONRESIDENT_1_DAY_FISHING", null, null, null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC23_NONRES_FRESHWATER_FISHING, AA23_NONRES_FRESHWATER_FISHING, FEE_ANL_NONRES_FRSHWTFSH_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRES_FRESHWATER_FISHING", "isRuleForSelectable_NONRES_FRESHWATER_FISHING", null, "getIncl_NONRES_FRESHWATER_FISHING", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC03_ONE_DAY_FISHING_LICENSE, AA03_ONE_DAY_FISHING_LICENSE, FEE_ONEDAY_FISH_SCHDL, "1", "getAllFeeCodeByRuleFor_ONEDAY_FISH_2012", "isRuleForSelectable_ONEDAY_FISH_2012", null, null, null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC26_SEVEN_DAY_FISHING_LICENSE, AA26_SEVEN_DAY_FISHING_LICENSE, FEE_ANNUAL_7DAY_FISHING_SCHDL, "1", "getAllFeeCodeByRuleFor_SEVEN_DAY_FISHING_LICENSE_2012", "isRuleForSelectable_SEVEN_DAY_FISHING_LICENSE_2012", null, null, null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC25_NONRESIDENT_7_DAY_FISHING, AA25_NONRESIDENT_7_DAY_FISHING, FEE_ANL_NONRES_7DAY_FISH_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_7_DAY_FISHING", "isRuleForSelectable_NONRESIDENT_7_DAY_FISHING", null, null, null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC02_MARINE_REGISTRY, AA02_MARINE_REGISTRY, FEE_ANNUAL_MRIN_REGISTRY_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_MRIN", "isRuleForSelectable_ANNUAL_MRIN", null, null, null, false, false, false));

    emptyArray.push(new SalesItemProp(LIC09_LIFETIME_BOWHUNTING, AA09_LIFETIME_BOWHUNTING, FEE_LIFETIME_BOWHUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_BOWH", "isRuleForSelectable_LIFETM_BOWH", "getPrereq_LIFETM_BOWH", "getIncl_LIFETM_BOWH", "getTag_LIFETM_BOWH", true, false, false));
    emptyArray.push(new SalesItemProp(LIC10_LIFETIME_FISHING, AA10_LIFETIME_FISHING, FEE_LIFETIME_FISHING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_FISH", "isRuleForSelectable_LIFETM_FISH", null, "getIncl_LIFETM_FISH", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC11_LIFETIME_MUZZLELOADING, AA11_LIFETIME_MUZZLELOADING, FEE_LIFETM_MUZZLELOADING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_MUZZ", "isRuleForSelectable_LIFETM_MUZZ", "getPrereq_LIFETM_MUZZ", "getIncl_LIFETM_MUZZ", "getTag_LIFETM_MUZZ", true, false, false));
    emptyArray.push(new SalesItemProp(LIC12_LIFETIME_SMALL_AND_BIG_GAME, AA12_LIFETIME_SMALL_AND_BIG_GAME, FEE_LIFETM_SMALLBIG_GAME_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_SBGM", "isRuleForSelectable_LIFETM_SBGM", null, "getIncl_LIFETM_SBGM", "getTag_LIFETM_SBGM", true, false, true));
    emptyArray.push(new SalesItemProp(LIC13_LIFETIME_SPORTSMAN, AA13_LIFETIME_SPORTSMAN, FEE_LIFETIME_SPORTSMAN_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_SPRT", "isRuleForSelectable_LIFETM_SPRT", null, "getIncl_LIFETM_SPRT", "getTag_LIFETM_SPRT", true, false, true));
    emptyArray.push(new SalesItemProp(LIC14_LIFETIME_TRAPPING, AA14_LIFETIME_TRAPPING, FEE_LIFETIME_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_TRAP", "isRuleForSelectable_LIFETM_TRAP", null, "getIncl_LIFETM_TRAP", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC45_LIFETIME_INSCRIPTION, AA45_LIFETIME_INSCRIPTION, FEE_LIFETIME_INSCRIPTION_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_INSCRIPTION", "isRuleForSelectable_LIFETM_INSCRIPTION", "getPrereq_LIFETM_INSCRIPTION", null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC56_TAG_DRIV_LIC_IMM, AA55_TAG_DRIV_LIC_IMM, FEE_LIFETIME_DRIV_LIC_SCHDL, "1", "getAllFeeCodeByRuleFor_DRIV_LIC_IMM", "isRuleForSelectable_DRIV_LIC", "getPrereq_DRIV_LIC", null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC57_TAG_DRIV_LIC_REN, AA56_TAG_DRIV_LIC_REN, FEE_LIFETIME_DRIV_LIC_SCHDL, "1", "getAllFeeCodeByRuleFor_DRIV_LIC_REN", "isRuleForSelectable_DRIV_LIC", "getPrereq_DRIV_LIC", null, null, false, false, false));

    emptyArray.push(new SalesItemProp(LIC32_NONRESIDENT_BEAR_TAG, AA32_NONRESIDENT_BEAR_TAG, FEE_TAG_BEAR_SCHDL, "1", "getAllFeeCodeByRuleFor_NONRESIDENT_BEAR_TAG", "isRuleForSelectable_NONRESIDENT_BEAR_TAG", "getPrereq_NONRESIDENT_BEAR_TAG", null, "getTag_NONRESIDENT_BEAR_TAG", true, false, false));

    emptyArray.push(new SalesItemProp(LIC16_HABITAT_ACCESS_STAMP, AA16_HABITAT_ACCESS_STAMP, FEE_OTHER_SL_HABITATACES_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_HABITAT_ACCESS_SCHDL", "isRuleForSelectable_OTHER_SALE_HABITAT_ACCESS_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC17_VENISON_DONATION, AA17_VENISON_DONATION, FEE_OTHER_SL_VENISONDNTN_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_VENISON_DONATION_SCHDL", "isRuleForSelectable_OTHER_SALE_VENISON_DONATION_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC18_CONSERVATION_FUND, AA18_CONSERVATION_FUND, FEE_OTHER_SL_CONSERVFUND_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_FUND", "isRuleForSelectable_OTHER_SALE_CONSERVATION_FUND", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC19_TRAIL_SUPPORTER_PATCH, AA19_TRAIL_SUPPORTER_PATCH, FEE_OTHER_SL_TRAILSUPP_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_TRAIL_SUPPORTER_PATCH_SCHDL", "isRuleForSelectable_OTHER_SALE_TRAIL_SUPPORTER_PATCH_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC20_CONSERVATIONIST_MAGAZINE, AA20_CONSERVATIONIST_MAGAZINE, FEE_OTHER_SL_CONSRVMGZNE_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_MAGAZINE", "isRuleForSelectable_OTHER_SALE_CONSERVATION_MAGAZINE", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC21_CONSERVATION_PATRON, AA21_CONSERVATION_PATRON, FEE_OTHER_SL_CONSERVPTRN_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_PATRON_SCHDL", "isRuleForSelectable_OTHER_SALE_CONSERVATION_PATRON_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC43_LIFETIME_CARD_REPLACE, AA43_LIFETIME_CARD_REPLACE, FEE_OTHER_SL_LFTMCRDREP_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETIME_CARD_REPLACE", "isRuleForSelectable_LIFETIME_CARD_REPLACE", null, null, null, false, false, false));
    //    emptyArray.push(new SalesItemProp(LIC44_SPORTSMAN_ED_CERTIFICATION, AA44_SPORTSMAN_ED_CERTIFICATION, FEE_OTHER_SL_SPORTEDCERT_SCHDL, "1", "getAllFeeCodeByRuleFor_SPORTSMAN_ED_CERTIFICATION", "isRuleForSelectable_SPORTSMAN_ED_CERTIFICATION", null, null, null, false, false, false));		// See below...Raj
    emptyArray.push(new SalesItemProp(LIC44_SPORTSMAN_ED_CERTIFICATION, AA44_SPORTSMAN_ED_CERTIFICATION, FEE_OTHER_SL_SPORTEDCERT_SCHDL, "1", "getAllFeeCodeByRuleFor_SPORTSMAN_ED_CERTIFICATION", "isRuleForSelectable_SPORTSMAN_ED_CERTIFICATION", null, null, null, true, false, true));
    return emptyArray;
}
function SetVesrionSalesItems2014() {
    var emptyArray = new Array();

    emptyArray.push(new SalesItemProp(LIC01_JUNIOR_HUNTING_TAGS, AA57_JUNIOR_HUNTING_TAGS, FEE_ANL_JUNIOR_HUNT_TAG_SCHDL, "1", "getAllFeeCodeByRuleFor_JUNIOR_HUNT_TAGS", "isRuleForSelectable_JUNIOR_HUNT_TAGS", null, null, "getTag_JUNIOR_HUNT_TAGS", true, false, false));
    emptyArray.push(new SalesItemProp(LIC02_MARINE_REGISTRY, AA02_MARINE_REGISTRY, FEE_ANNUAL_MRIN_REGISTRY_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_MRIN", "isRuleForSelectable_ANNUAL_MRIN", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC03_ONE_DAY_FISHING_LICENSE, AA03_ONE_DAY_FISHING_LICENSE, FEE_ONEDAY_FISH_SCHDL, "2", "getAllFeeCodeByRuleFor_ONEDAY_FISH_2014", "isRuleForSelectable_ONEDAY_FISH_2014", null, null, null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC04_BOWHUNTING_PRIVILEGE, AA04_BOWHUNTING_PRIVILEGE, FEE_ANNUAL_BOWHUNTING_SCHDL, "2", "getAllFeeCodeByRuleFor_ANNUAL_BOWH_2014", "isRuleForSelectable_ANNUAL_BOWH_2014", "getPrereq_ANNUAL_BOWH_2014", "getIncl_ANNUAL_BOWH", "getTag_ANNUAL_BOWH_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC05_DEER_MANAGEMENT_PERMIT, AA05_DEER_MANAGEMENT_PERMIT, FEE_ANNUAL_DMP_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_DMP", "isRuleForSelectable_ANNUAL_DMP_2014", "getPrereq_ANNUAL_DMP_2014", null, "getTag_ANNUAL_DMP_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC06_HUNTING_LICENSE, AA06_HUNTING_LICENSE, FEE_ANNUAL_HUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_ANNUAL_HUNT", "isRuleForSelectable_ANNUAL_HUNT", null, "getIncl_ANNUAL_HUNT", "getTag_ANNUAL_HUNT", true, false, false));
    emptyArray.push(new SalesItemProp(LIC07_MUZZLELOADING_PRIVILEGE, AA07_MUZZLELOADING_PRIVILEGE, FEE_ANNUAL_MUZZLELOADING_SCHDL, "2", "getAllFeeCodeByRuleFor_ANNUAL_MUZZ_2014", "isRuleForSelectable_ANNUAL_MUZZ_2014", "getPrereq_ANNUAL_MUZZ_2014", "getIncl_ANNUAL_MUZZ", "getTag_ANNUAL_MUZZ_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC08_TURKEY_PERMIT, AA08_TURKEY_PERMIT, FEE_ANNUAL_TURKEY_PERMIT_SCHDL, "2", "getAllFeeCodeByRuleFor_ANNUAL_TRKY_2014", "isRuleForSelectable_ANNUAL_TRKY_2014", "getPrereq_ANNUAL_TRKY_2014", "getIncl_ANNUAL_TRKY", "getTag_ANNUAL_TRKY_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC09_LIFETIME_BOWHUNTING, AA09_LIFETIME_BOWHUNTING, FEE_LIFETIME_BOWHUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_BOWH", "isRuleForSelectable_LIFETM_BOWH", "getPrereq_LIFETM_BOWH", "getIncl_LIFETM_BOWH", "getTag_LIFETM_BOWH", true, false, false));
    emptyArray.push(new SalesItemProp(LIC10_LIFETIME_FISHING, AA10_LIFETIME_FISHING, FEE_LIFETIME_FISHING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_FISH", "isRuleForSelectable_LIFETM_FISH", null, "getIncl_LIFETM_FISH", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC11_LIFETIME_MUZZLELOADING, AA11_LIFETIME_MUZZLELOADING, FEE_LIFETM_MUZZLELOADING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_MUZZ", "isRuleForSelectable_LIFETM_MUZZ", "getPrereq_LIFETM_MUZZ", "getIncl_LIFETM_MUZZ", "getTag_LIFETM_MUZZ", true, false, false));
    emptyArray.push(new SalesItemProp(LIC12_LIFETIME_SMALL_AND_BIG_GAME, AA12_LIFETIME_SMALL_AND_BIG_GAME, FEE_LIFETM_SMALLBIG_GAME_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_SBGM", "isRuleForSelectable_LIFETM_SBGM", null, "getIncl_LIFETM_SBGM", "getTag_LIFETM_SBGM", true, false, true));
    emptyArray.push(new SalesItemProp(LIC13_LIFETIME_SPORTSMAN, AA13_LIFETIME_SPORTSMAN, FEE_LIFETIME_SPORTSMAN_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_SPRT", "isRuleForSelectable_LIFETM_SPRT", null, "getIncl_LIFETM_SPRT", "getTag_LIFETM_SPRT", true, false, true));
    emptyArray.push(new SalesItemProp(LIC14_LIFETIME_TRAPPING, AA14_LIFETIME_TRAPPING, FEE_LIFETIME_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_TRAP", "isRuleForSelectable_LIFETM_TRAP", null, "getIncl_LIFETM_TRAP", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC15_TRAPPING_LICENSE, AA15_TRAPPING_LICENSE, FEE_ANNUAL_TRAPPING_SCHDL, "2", "getAllFeeCodeByRuleFor_ANNUAL_TRAP_2014", "isRuleForSelectable_ANNUAL_TRAP_2014", null, "getIncl_ANNUAL_TRAP", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC16_HABITAT_ACCESS_STAMP, AA16_HABITAT_ACCESS_STAMP, FEE_OTHER_SL_HABITATACES_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_HABITAT_ACCESS_SCHDL", "isRuleForSelectable_OTHER_SALE_HABITAT_ACCESS_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC17_VENISON_DONATION, AA17_VENISON_DONATION, FEE_OTHER_SL_VENISONDNTN_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_VENISON_DONATION_SCHDL", "isRuleForSelectable_OTHER_SALE_VENISON_DONATION_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC18_CONSERVATION_FUND, AA18_CONSERVATION_FUND, FEE_OTHER_SL_CONSERVFUND_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_FUND", "isRuleForSelectable_OTHER_SALE_CONSERVATION_FUND", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC19_TRAIL_SUPPORTER_PATCH, AA19_TRAIL_SUPPORTER_PATCH, FEE_OTHER_SL_TRAILSUPP_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_TRAIL_SUPPORTER_PATCH_SCHDL", "isRuleForSelectable_OTHER_SALE_TRAIL_SUPPORTER_PATCH_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC20_CONSERVATIONIST_MAGAZINE, AA20_CONSERVATIONIST_MAGAZINE, FEE_OTHER_SL_CONSRVMGZNE_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_MAGAZINE", "isRuleForSelectable_OTHER_SALE_CONSERVATION_MAGAZINE", null, null, null, false, false, false));
    //emptyArray.push(new SalesItemProp(LIC21_CONSERVATION_PATRON, AA21_CONSERVATION_PATRON, FEE_OTHER_SL_CONSERVPTRN_SCHDL, "1", "getAllFeeCodeByRuleFor_OTHER_SALE_CONSERVATION_PATRON_SCHDL", "isRuleForSelectable_OTHER_SALE_CONSERVATION_PATRON_SCHDL", null, null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC22_FRESHWATER_FISHING, AA22_FRESHWATER_FISHING, FEE_ANL_FRESHWATER_FISH_SCHDL, "2", "getAllFeeCodeByRuleFor_FRESHWATER_FISHING_2014", "isRuleForSelectable_FRESHWATER_FISHING_2014", null, "getIncl_FRESHWATER_FISHING_2014", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC26_SEVEN_DAY_FISHING_LICENSE, AA26_SEVEN_DAY_FISHING_LICENSE, FEE_ANNUAL_7DAY_FISHING_SCHDL, "2", "getAllFeeCodeByRuleFor_SEVEN_DAY_FISHING_LICENSE_2014", "isRuleForSelectable_SEVEN_DAY_FISHING_LICENSE_2014", null, null, null, false, false, true));

    emptyArray.push(new SalesItemProp(LIC43_LIFETIME_CARD_REPLACE, AA43_LIFETIME_CARD_REPLACE, FEE_OTHER_SL_LFTMCRDREP_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETIME_CARD_REPLACE", "isRuleForSelectable_LIFETIME_CARD_REPLACE", null, null, null, true, true, true));
    emptyArray.push(new SalesItemProp(LIC44_SPORTSMAN_ED_CERTIFICATION, AA44_SPORTSMAN_ED_CERTIFICATION, FEE_OTHER_SL_SPORTEDCERT_SCHDL, "1", "getAllFeeCodeByRuleFor_SPORTSMAN_ED_CERTIFICATION", "isRuleForSelectable_SPORTSMAN_ED_CERTIFICATION", null, null, null, true, true, true));
    emptyArray.push(new SalesItemProp(LIC45_LIFETIME_INSCRIPTION, AA45_LIFETIME_INSCRIPTION, FEE_LIFETIME_INSCRIPTION_SCHDL, "1", "getAllFeeCodeByRuleFor_LIFETM_INSCRIPTION", "isRuleForSelectable_LIFETM_INSCRIPTION", "getPrereq_LIFETM_INSCRIPTION", null, null, false, false, false));

    emptyArray.push(new SalesItemProp(LIC56_TAG_DRIV_LIC_IMM, AA55_TAG_DRIV_LIC_IMM, FEE_LIFETIME_DRIV_LIC_SCHDL, "1", "getAllFeeCodeByRuleFor_DRIV_LIC_IMM", "isRuleForSelectable_DRIV_LIC", "getPrereq_DRIV_LIC", null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC57_TAG_DRIV_LIC_REN, AA56_TAG_DRIV_LIC_REN, FEE_LIFETIME_DRIV_LIC_SCHDL, "1", "getAllFeeCodeByRuleFor_DRIV_LIC_REN", "isRuleForSelectable_DRIV_LIC", "getPrereq_DRIV_LIC", null, null, false, false, false));
    emptyArray.push(new SalesItemProp(LIC58_HUNTING_LICENSE_3Y, AA58_HUNTING_LICENSE_3Y, FEE_3YEAR_HUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_HUNT", "isRuleForSelectable_3Y_HUNT", null, "getIncl_3Y_HUNT", "getTag_ANNUAL_HUNT", true, false, false));
    emptyArray.push(new SalesItemProp(LIC59_HUNTING_LICENSE_5Y, AA59_HUNTING_LICENSE_5Y, FEE_5YEAR_HUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_HUNT", "isRuleForSelectable_5Y_HUNT", null, "getIncl_5Y_HUNT", "getTag_ANNUAL_HUNT", true, false, false));
    emptyArray.push(new SalesItemProp(LIC60_BOWHUNTING_PRIVILEGE_3Y, AA60_BOWHUNTING_PRIVILEGE_3Y, FEE_3YEAR_BOWHUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_BOWH", "isRuleForSelectable_3Y_BOWH", "getPrereq_3Y_BOWH", "getIncl_3Y_BOWH", "getTag_ANNUAL_BOWH_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC61_BOWHUNTING_PRIVILEGE_5Y, AA61_BOWHUNTING_PRIVILEGE_5Y, FEE_5YEAR_BOWHUNTING_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_BOWH", "isRuleForSelectable_5Y_BOWH", "getPrereq_5Y_BOWH", "getIncl_5Y_BOWH", "getTag_ANNUAL_BOWH_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC62_MUZZLELOADING_PRIVILEGE_3Y, AA62_MUZZLELOADING_PRIVILEGE_3Y, FEE_3YEAR_MUZZLELOADING_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_MUZZ", "isRuleForSelectable_3Y_MUZZ", "getPrereq_3Y_MUZZ", "getIncl_3Y_MUZZ", "getTag_ANNUAL_MUZZ_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC63_MUZZLELOADING_PRIVILEGE_5Y, AA63_MUZZLELOADING_PRIVILEGE_5Y, FEE_5YEAR_MUZZLELOADING_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_MUZZ", "isRuleForSelectable_5Y_MUZZ", "getPrereq_5Y_MUZZ", "getIncl_5Y_MUZZ", "getTag_ANNUAL_MUZZ_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC64_TRAPPING_LICENSE_3Y, AA64_TRAPPING_LICENSE_3Y, FEE_3YEAR_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_TRAP", "isRuleForSelectable_3Y_TRAP", null, "getIncl_3Y_TRAP", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC65_TRAPPING_LICENSE_5Y, AA65_TRAPPING_LICENSE_5Y, FEE_5YEAR_TRAPPING_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_TRAP", "isRuleForSelectable_5Y_TRAP", null, "getIncl_5Y_TRAP", null, false, true, false));
    emptyArray.push(new SalesItemProp(LIC66_FRESHWATER_FISHING_3Y, AA66_FRESHWATER_FISHING_3Y, FEE_3YEAR_FISHING_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_FRESHWATER_FISHING", "isRuleForSelectable_3Y_FRESHWATER_FISHING", null, "getIncl_3Y_FRESHWATER_FISHING", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC67_FRESHWATER_FISHING_5Y, AA67_FRESHWATER_FISHING_5Y, FEE_5YEAR_FISHING_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_FRESHWATER_FISHING", "isRuleForSelectable_5Y_FRESHWATER_FISHING", null, "getIncl_5Y_FRESHWATER_FISHING", null, false, false, true));
    emptyArray.push(new SalesItemProp(LIC68_TURKEY_PERMIT_3Y, AA68_TURKEY_PERMIT_3Y, FEE_3YEAR_TURKEY_PERMIT_SCHDL, "1", "getAllFeeCodeByRuleFor_3Y_TRKY", "isRuleForSelectable_3Y_TRKY", "getPrereq_3Y_TRKY_2014", "getIncl_3Y_TRKY", "getTag_ANNUAL_TRKY_2014", true, false, false));
    emptyArray.push(new SalesItemProp(LIC69_TURKEY_PERMIT_5Y, AA69_TURKEY_PERMIT_5Y, FEE_5YEAR_TURKEY_PERMIT_SCHDL, "1", "getAllFeeCodeByRuleFor_5Y_TRKY", "isRuleForSelectable_5Y_TRKY", "getPrereq_5Y_TRKY_2014", "getIncl_5Y_TRKY", "getTag_ANNUAL_TRKY_2014", true, false, false));

    return emptyArray;
}
	