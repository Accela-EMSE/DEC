//var recordType = 'Licenses/Other/Sales/Habitat or Access Stamp';
//var quantityField = 'Quantity Habitat/Access Stamp';
//getCorrectTheQuantity(recordType, quantityField);
function getCorrectTheQuantity(recordType, QuantityField) {
	var ata = recordType.split("/");
	
	var sql = "SELECT ";
	sql += " A.B1_ALT_ID K_ALT_ID, B.B1_CHECKBOX_DESC K_QTY_F, B.B1_CHECKLIST_COMMENT K_QTY_V, ";
	sql += " P.B1_ALT_ID P_ALT_ID, PC.B1_CHECKBOX_DESC P_QTY_F, PC.B1_CHECKLIST_COMMENT P_QTY_V ";
	sql += " FROM b1permit A ";
	sql += " inner join bchckbox B ";
	sql += " ON A.serv_prov_code = B.serv_prov_code ";
	sql += " AND A.b1_per_id1 = B.b1_per_id1 ";
	sql += " AND A.b1_per_id2 = B.b1_per_id2 ";
	sql += " AND A.b1_per_id3 = B.b1_per_id3 ";
	sql += " join xapp2ref APPREF ";
	sql += " ON A.serv_prov_code = APPREF.serv_prov_code ";
	sql += " AND A.b1_per_id1 = APPREF.b1_per_id1 ";
	sql += " AND A.b1_per_id2 = APPREF.b1_per_id2 ";
	sql += " AND A.b1_per_id3 = APPREF.b1_per_id3 ";
	sql += " join b1permit P ";
	sql += " ON APPREF.serv_prov_code = P.serv_prov_code ";
	sql += " AND APPREF.b1_master_id1 = P.b1_per_id1 ";
	sql += " AND APPREF.b1_master_id2 = P.b1_per_id2 ";
	sql += " AND APPREF.b1_master_id3 = P.b1_per_id3 ";
	sql += " join bchckbox PC ";
	sql += " ON P.serv_prov_code = PC.serv_prov_code ";
	sql += " AND P.b1_per_id1 = PC.b1_per_id1 ";
	sql += " AND P.b1_per_id2 = PC.b1_per_id2 ";
	sql += " AND P.b1_per_id3 = PC.b1_per_id3 ";
	sql += " WHERE  A.serv_prov_code = 'DEC' ";
	sql += " AND A.b1_per_group = '" + ata[0] + "' ";
	sql += " AND A.b1_per_type = '" + ata[1] + "' ";
	sql += " AND A.b1_per_sub_type = '" + ata[2] + "' ";
	sql += " AND A.b1_per_category = '" + ata[3] + "' ";
	sql += " AND A.rec_date >= To_date('01/01/2014', 'mm/dd/yyyy') ";
	sql += " AND B.b1_checkbox_desc = 'Quantity' ";
	sql += " AND Pc.b1_checkbox_desc = '" + QuantityField + "' ";
	sql += " AND PC.b1_checklist_comment != B.b1_checklist_comment ";

    var initialContext = aa.proxyInvoker.newInstance("javax.naming.InitialContext", null).getOutput();
    var ds = initialContext.lookup("java:/AA");
    var conn = ds.getConnection();

    var sStmt = conn.prepareStatement(sql);
    var rSet = sStmt.executeQuery();
    while (rSet.next()) {
		var kAltId = rSet.getString("K_ALT_ID");
		var sv = rSet.getString("K_QTY_V");
		var dv = rSet.getString("P_QTY_V");

        var itemCapId = getCapId(kAltId);
		
		var newAInfo = new Array();
        newAInfo.push(new NewLicDef("Quantity", dv));

		copyLicASI(itemCapId, newAInfo);
		aa.print(itemCapId);
	}
}

