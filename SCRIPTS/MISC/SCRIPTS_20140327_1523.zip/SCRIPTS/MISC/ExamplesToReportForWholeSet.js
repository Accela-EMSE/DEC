/*------------------------------------------------------------------------------------------------------/
| Test Parameters - Modify as needed
/------------------------------------------------------------------------------------------------------*/
var myCapId = "361314002568" //DEC-LS-14001379 //DEC-LS-14001380

var myUserId = "ADMIN";
documentOnly = false;

var controlString = ""; 	// Standard Choice Starting Point
var preExecute = ""  	// Standard choice to execute first (for globals, etc) (PreExecuteForAfterEvent or PreExecuteForBeforeEvents)

/*------------------------------------------------------------------------------------------------------/
| Set Required Environment Variables Value
/------------------------------------------------------------------------------------------------------*/
var tmpID = aa.cap.getCapID(myCapId).getOutput();
if (tmpID != null) {
    aa.env.setValue("PermitId1", tmpID.getID1());
    aa.env.setValue("PermitId2", tmpID.getID2());
    aa.env.setValue("PermitId3", tmpID.getID3());
}
aa.env.setValue("CurrentUserID", myUserId);

/*------------------------------------------------------------------------------------------------------/
| Log Globals and Add Includes
/------------------------------------------------------------------------------------------------------*/
var SCRIPT_VERSION = 2.0

eval(getScriptText("INCLUDES_ACCELA_FUNCTIONS"));
eval(getScriptText("INCLUDES_ACCELA_GLOBALS"));
eval(getScriptText("INCLUDES_CUSTOM"));

showMessage = true; showDebug = true;

if (documentOnly) {
    doStandardChoiceActions(controlString, false, 0);
    aa.env.setValue("ScriptReturnCode", "0");
    aa.env.setValue("ScriptReturnMessage", "Documentation Successful.  No actions executed.");
    aa.abortScript();
}

function getScriptText(vScriptName) {
    vScriptName = vScriptName.toUpperCase();
    var emseBiz = aa.proxyInvoker.newInstance("com.accela.aa.emse.emse.EMSEBusiness").getOutput();
    var emseScript = emseBiz.getScriptByPK(aa.getServiceProviderCode(), vScriptName, "ADMIN");
    return emseScript.getScriptText() + "";
}

/*------------------------------------------------------------------------------------------------------/
| Execute Script Controls
/------------------------------------------------------------------------------------------------------*/

if (preExecute.length) doStandardChoiceActions(preExecute, true, 0); 	// run Pre-execution code

logGlobals(AInfo);

//doStandardChoiceActions(controlString, true, 0);
MyStartingPoint(capId);
//
// Check for invoicing of fees
//
if (feeSeqList.length) {
    invoiceResult = aa.finance.createInvoice(capId, feeSeqList, paymentPeriodList);
    if (invoiceResult.getSuccess())
        logMessage("Invoicing assessed fee items is successful.");
    else
        logMessage("**ERROR: Invoicing the fee items assessed to app # " + capIDString + " was not successful.  Reason: " + invoiceResult.getErrorMessage());
}

/*------------------------------------------------------------------------------------------------------/
| <===========END=Main=Loop================>
/-----------------------------------------------------------------------------------------------------*/

if (debug.indexOf("**ERROR") > 0) {
    aa.env.setValue("ScriptReturnCode", "1");
    aa.env.setValue("ScriptReturnMessage", debug);
}
else {
    aa.env.setValue("ScriptReturnCode", "0");
    if (showMessage) aa.env.setValue("ScriptReturnMessage", message);
    if (showDebug) aa.env.setValue("ScriptReturnMessage", debug);
}

/*------------------------------------------------------------------------------------------------------/
| End test code
/------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------/
| <===========External Functions (used by Action entries)
/------------------------------------------------------------------------------------------------------*/
function MyStartingPoint(itemCap) {
	var setName
    var settprocess = new capSet("DAILY_03/21/2014_4");
    var vSetMembers = settprocess.members;
    for (thisCap in vSetMembers) {
        var recca = String(vSetMembers[thisCap]).split("-");
		var itemCapId = aa.cap.getCapID(recca[0], recca[1], recca[2]).getOutput();
		aa.print(itemCapId);
		var itemCap = aa.cap.getCap(itemCapId).getOutput();
		generateReport(itemCapId);
	}
}

// Generate Report.
function generateReport(itemCapId) {
var reportName = "License Tags";
    var parameters = aa.util.newHashMap();
    parameters.put("PARENT", itemCapId.getCustomID());

    var report = aa.reportManager.getReportInfoModelByName(reportName);
    report = report.getOutput();
    //aa.print(report);
    report.setCapId(itemCapId.toString());
    report.setModule("Licenses");
    report.setReportParameters(parameters);
    // set the alt-id as that's what the EDMS is using.
    report.getEDMSEntityIdModel().setAltId(itemCapId.getCustomID());
    var checkPermission = aa.reportManager.hasPermission(reportName, "admin");
    logDebug("Permission for report: " + checkPermission.getOutput().booleanValue());
	
    if (checkPermission.getOutput().booleanValue()) {
        logDebug("User has permission");
        var reportResult = aa.reportManager.getReportResult(report);
        // not needed as the report is set up for EDMS
        if (false) {
            reportResult = reportResult.getOutput();
            logDebug("Report result: " + reportResult);
            reportFile = aa.reportManager.storeReportToDisk(reportResult);
            reportFile = reportFile.getOutput();
            logDebug("Report File: " + reportFile);
        }
    }
}

