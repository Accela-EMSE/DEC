	/*------------------------------------------------------------------------------------------------------/
	| Test Parameters - Modify as needed
	/------------------------------------------------------------------------------------------------------*/
	var myCapId = "DEC-LS-14000894" //DEC-LS-14001379 //DEC-LS-14001380

	var myUserId = "ADMIN";
	documentOnly = false;

	var controlString = ""; 	// Standard Choice Starting Point
	var preExecute = ""  	// Standard choice to execute first (for globals, etc) (PreExecuteForAfterEvent or PreExecuteForBeforeEvents)

	/*------------------------------------------------------------------------------------------------------/
	| Set Required Environment Variables Value
	/------------------------------------------------------------------------------------------------------*/
	var tmpID = aa.cap.getCapID(myCapId).getOutput();
	if (tmpID != null) {
		aa.env.setValue("PermitId1", tmpID.getID1());
		aa.env.setValue("PermitId2", tmpID.getID2());
		aa.env.setValue("PermitId3", tmpID.getID3());
	}
	aa.env.setValue("CurrentUserID", myUserId);

	/*------------------------------------------------------------------------------------------------------/
	| Log Globals and Add Includes
	/------------------------------------------------------------------------------------------------------*/
	var SCRIPT_VERSION = 2.0

	eval(getScriptText("INCLUDES_ACCELA_FUNCTIONS"));
	eval(getScriptText("INCLUDES_ACCELA_GLOBALS"));
	eval(getScriptText("INCLUDES_CUSTOM"));

	showMessage = true; showDebug = true;

	if (documentOnly) {
		doStandardChoiceActions(controlString, false, 0);
		aa.env.setValue("ScriptReturnCode", "0");
		aa.env.setValue("ScriptReturnMessage", "Documentation Successful.  No actions executed.");
		aa.abortScript();
	}

	function getScriptText(vScriptName) {
		vScriptName = vScriptName.toUpperCase();
		var emseBiz = aa.proxyInvoker.newInstance("com.accela.aa.emse.emse.EMSEBusiness").getOutput();
		var emseScript = emseBiz.getScriptByPK(aa.getServiceProviderCode(), vScriptName, "ADMIN");
		return emseScript.getScriptText() + "";
	}

	/*------------------------------------------------------------------------------------------------------/
	| Execute Script Controls
	/------------------------------------------------------------------------------------------------------*/

	if (preExecute.length) doStandardChoiceActions(preExecute, true, 0); 	// run Pre-execution code

	logGlobals(AInfo);

	//doStandardChoiceActions(controlString, true, 0);
	MyStartingPoint(capId);
	//
	// Check for invoicing of fees
	//
	if (feeSeqList.length) {
		invoiceResult = aa.finance.createInvoice(capId, feeSeqList, paymentPeriodList);
		if (invoiceResult.getSuccess())
			logMessage("Invoicing assessed fee items is successful.");
		else
			logMessage("**ERROR: Invoicing the fee items assessed to app # " + capIDString + " was not successful.  Reason: " + invoiceResult.getErrorMessage());
	}

	/*------------------------------------------------------------------------------------------------------/
	| <===========END=Main=Loop================>
	/-----------------------------------------------------------------------------------------------------*/

	if (debug.indexOf("**ERROR") > 0) {
		aa.env.setValue("ScriptReturnCode", "1");
		aa.env.setValue("ScriptReturnMessage", debug);
	}
	else {
		aa.env.setValue("ScriptReturnCode", "0");
		if (showMessage) aa.env.setValue("ScriptReturnMessage", message);
		if (showDebug) aa.env.setValue("ScriptReturnMessage", debug);
	}

	/*------------------------------------------------------------------------------------------------------/
	| End test code
	/------------------------------------------------------------------------------------------------------*/
	/*------------------------------------------------------------------------------------------------------/
	| <===========External Functions (used by Action entries)
	/------------------------------------------------------------------------------------------------------*/
	function MyStartingPoint(itemCap) {

var sql = "SELECT KID.b1_alt_id AS RecorId, KID.B1_PER_ID1, KID.B1_PER_ID2, KID.B1_PER_ID3, "
sql += " KID.b1_special_text, ";
sql += " f4.gf_cod, ";
sql += " Decode(f4.gf_cod, 'AHL_1_RES', '300','AHL_2_NORES', '301','AHL_3_RES', '302','AHL_4_NORES', '303','AHL_5_RES', '304','AHL_6_RESMD', '305','AHL_7_NAM', '306','AHL_8_PATR', '307','AHL_9_NORES', '308',        'AHL_10_RES', '309') as item_code ";
sql += " FROM   "; 
sql += " b1permit PARENTS ";
sql += " inner join xapp2ref APPREF  ";
sql += " On PARENTS.serv_prov_code = APPREF.serv_prov_code "; 
sql += " AND PARENTS.b1_per_id1 = APPREF.b1_master_id1  ";
sql += " AND PARENTS.b1_per_id2 = APPREF.b1_master_id2  ";
sql += " AND PARENTS.b1_per_id3 = APPREF.b1_master_id3  ";
sql += " inner join b1permit KID on  ";
sql += " APPREF.serv_prov_code = KID.serv_prov_code "; 
sql += " AND APPREF.b1_per_id1 = KID.b1_per_id1  ";
sql += " AND APPREF.b1_per_id2 = KID.b1_per_id2  ";
sql += " AND APPREF.b1_per_id3 = KID.b1_per_id3  ";
sql += " inner join f4feeitem f4 ";
sql += " On PARENTS.serv_prov_code = f4.serv_prov_code  ";
sql += " AND PARENTS.b1_per_id1 = f4.b1_per_id1  ";
sql += " AND PARENTS.b1_per_id2 = f4.b1_per_id2  ";
sql += " AND PARENTS.b1_per_id3 = f4.b1_per_id3  ";
sql += " WHERE  PARENTS.serv_prov_code = 'DEC'  ";
sql += " AND Trunc(KID.b1_file_dd) >= To_date('01-FEB-2014')  ";
sql += " AND KID.b1_appl_status = 'Active'  ";
sql += " AND KID.b1_per_group = 'Licenses'  ";
sql += " AND KID.b1_per_type = 'Annual'  ";
sql += " AND KID.b1_per_sub_type = 'Hunting'  ";
sql += " AND KID.B1_PER_CATEGORY = 'Hunting'  ";
sql += " AND f4.gf_cod like ( 'AHL_%') ";

    var initialContext = aa.proxyInvoker.newInstance("javax.naming.InitialContext", null).getOutput();
    var ds = initialContext.lookup("java:/AA");
    var conn = ds.getConnection();

    var sStmt = conn.prepareStatement(sql);
    var rSet = sStmt.executeQuery();

    while (rSet.next()) {
        var capIdModel = aa.cap.getCapID(rSet.getString("B1_PER_ID1"), rSet.getString("B1_PER_ID2"), rSet.getString("B1_PER_ID3")).getOutput();
		var feeCode = rSet.getString("gf_cod")
		var itemCode = rSet.getString("item_code")
		var altId = rSet.getString("RecorId")
		
        var itemCap = aa.cap.getCapBasicInfo(capIdModel).getOutput();
        var itemCapId = itemCap.getCapID();
		var desc = GetItemCodedesc(itemCode);

		aa.print(altId + ":" + itemCapId + ":" + itemCode + ":" + desc);

		editAppName(desc, itemCapId);
		var newAInfo = new Array();
        newAInfo.push(new NewLicDef("Item Code", itemCode));
		copyLicASI(itemCapId, newAInfo);
		
	}

}


